<br />
<div align="center">

  <img src="assets/GoogleChatTranslatorLogo.png" alt="Logo" width="80" height="80">
  <h2 align="center">Google Chat Translator</h2>
 
</div>

## About The Project

This is a small Google Chrome extension for translating your Google Chat messages into your desired language.

### Built With

<div> 
  <img  alt="HTML5" width="39px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png" /> 
  <img  alt="CSS3" width="39px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png" />
  <img  alt="JavaScript" width="31px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png" />
</div>




### Setup
1. Clone the repo
   
   ```sh 
   git clone https://github.com/leoarokiaraj/GoogleChatTranslator.git
   ```
   
2. Get your api Key at - https://aistudio.google.com/app/apikey
   
3. Update your api key in `google-appscript/code.gs`
   
    ```sh
       var url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=<GEMINI-API-KEY>";
    ```


### Installation

1. Deploy the `google-appscript/code.gs` in Google App Script as a Web App.

2. Zip the code content and install it as a Chrome Extension

### Usage

1. Choose the language in Extension window

3. Click `See translation` button below each message for translation.

   
   
